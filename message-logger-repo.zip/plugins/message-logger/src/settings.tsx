import { ReactNative } from "@vendetta/metro/common";
import { findByProps } from "@vendetta/metro";
import { Forms } from "@vendetta/ui/components";
import { getAssetIDByName } from "@vendetta/ui/assets";
import { storage } from "@vendetta/plugin";
import { useProxy } from "@vendetta/storage";
import { showToast } from "@vendetta/ui/toasts";

const { FormIcon, FormSwitchRow, FormRow, FormSection, FormDivider, FormText } = Forms;
const { Alert, ScrollView } = ReactNative;

const FileModule: any =
  ReactNative.NativeModules.DCDFileManager ??
  findByProps("writeFile", "readFile", "getConstants");

storage.nopk            ??= false;
storage.deletedMessages ??= {};

export default () => {
  useProxy(storage);

  const logs = storage.deletedMessages as Record<string, Record<string, any>>;

  // Count messages and media files across all channels
  let totalMsgs  = 0;
  let totalMedia = 0;

  for (const cid of Object.keys(logs)) {
    for (const entry of Object.values(logs[cid])) {
      totalMsgs++;
      totalMedia += (entry.localAttachments ?? []).filter((a: any) => a.localPath).length;
    }
  }

  const channelCount = Object.keys(logs).length;

  /** Delete all saved local media files then wipe storage. */
  const clearAll = async () => {
    // Try to delete each saved local file from disk
    for (const cid of Object.keys(logs)) {
      for (const entry of Object.values(logs[cid])) {
        for (const att of (entry.localAttachments ?? [])) {
          if (!att.localPath) continue;
          try {
            // Extract filename from file:// URI and delete
            const filename = att.localPath.split("/").pop();
            if (filename) await FileModule.deleteFile("documents", filename);
          } catch { /* file already gone — ignore */ }
        }
      }
    }

    storage.deletedMessages = {};
    showToast("Cleared all saved messages and media", getAssetIDByName("ic_trash"));
  };

  const confirmClear = () => {
    if (totalMsgs === 0) return;
    Alert.alert(
      "Clear all saved messages?",
      `This will permanently delete:\n• ${totalMsgs} message${totalMsgs !== 1 ? "s" : ""}\n• ${totalMedia} media file${totalMedia !== 1 ? "s" : ""} saved to your device\n\nThis cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        { text: "Clear All", style: "destructive", onPress: clearAll },
      ]
    );
  };

  return (
    <ScrollView>

      {/* ── Filters ── */}
      <FormSection title="FILTERS">
        <FormSwitchRow
          label="Ignore PluralKit"
          subLabel="Don't log messages deleted by PluralKit proxying"
          leading={<FormIcon source={getAssetIDByName("ic_block")} />}
          onValueChange={(v: boolean) => void (storage.nopk = v)}
          value={storage.nopk}
        />
      </FormSection>

      {/* ── Persistent Log ── */}
      <FormSection title="PERSISTENT LOG">
        <FormRow
          label="Saved Messages"
          subLabel={
            totalMsgs === 0
              ? "No messages saved yet"
              : `${totalMsgs} message${totalMsgs !== 1 ? "s" : ""} across ${channelCount} channel${channelCount !== 1 ? "s" : ""}`
          }
          leading={<FormIcon source={getAssetIDByName("ic_message")} />}
        />
        <FormDivider />
        <FormRow
          label="Saved Media Files"
          subLabel={
            totalMedia === 0
              ? "No media downloaded yet"
              : `${totalMedia} image${totalMedia !== 1 ? "s" : ""}/video${totalMedia !== 1 ? "s" : ""} saved locally on your device`
          }
          leading={<FormIcon source={getAssetIDByName("ic_image")} />}
        />
        <FormDivider />
        <FormRow
          label="Clear All Saved Messages & Media"
          subLabel={
            totalMsgs === 0
              ? "Nothing to clear"
              : "Deletes all logs and removes media files from device storage"
          }
          leading={<FormIcon source={getAssetIDByName("ic_trash")} />}
          onPress={confirmClear}
          style={totalMsgs > 0 ? { color: "#da373c" } : { opacity: 0.4 }}
        />
      </FormSection>

      {/* ── Info ── */}
      <FormSection title="HOW MEDIA SAVING WORKS">
        <FormText style={{ paddingHorizontal: 16, paddingVertical: 12, opacity: 0.7 }}>
          When a message is deleted, the plugin immediately downloads all
          attachments, embed images, and embed videos to your device's local
          storage before Discord's CDN removes them. Saved files survive both
          app restarts and Discord's CDN expiry. Tapping{" "}
          <FormText style={{ fontWeight: "bold" }}>Clear All</FormText>{" "}
          removes both the message logs and the downloaded files from your device.
        </FormText>
      </FormSection>

    </ScrollView>
  );
};
