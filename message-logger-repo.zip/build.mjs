import { build } from "esbuild";
import { readdirSync, mkdirSync, copyFileSync, readFileSync } from "fs";

const PLUGINS_DIR = "plugins";

for (const pluginFolder of readdirSync(PLUGINS_DIR)) {
  const manifestPath = `${PLUGINS_DIR}/${pluginFolder}/manifest.json`;
  const manifest     = JSON.parse(readFileSync(manifestPath, "utf-8"));

  console.log(`Building ${manifest.name}...`);

  const outDir = `dist/${pluginFolder}`;
  mkdirSync(outDir, { recursive: true });

  await build({
    entryPoints: [`${PLUGINS_DIR}/${pluginFolder}/src/index.ts`],
    bundle:      true,
    format:      "iife",
    target:      "esnext",
    outfile:     `${outDir}/index.js`,
    // These are all provided by the Revenge runtime at load time
    external: [
      "@vendetta",
      "@vendetta/*",
    ],
    jsx:        "transform",
    jsxFactory: "React.createElement",
    jsxFragment:"React.Fragment",
    minify:     true,
  });

  copyFileSync(manifestPath, `${outDir}/manifest.json`);
  console.log(`  → dist/${pluginFolder}/`);
}

console.log("Done.");
